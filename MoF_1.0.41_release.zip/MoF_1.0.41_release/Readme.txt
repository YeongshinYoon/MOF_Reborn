Master of Fantasy

- Developer Release Version 1.0.41 (1st Release)

- Released Date : 2019.01.26 Sat. 16:00 (GMT +9)

- Default Key Settings
   1. Ctrl : 기본공격
   2. I : 인벤토리
   3. C : 캐릭터 정보
   4. S : 스킬창
   5. Q : 퀘스트

- Patch Notes
   1. 구현 된 몬스터 : 초, 일개미, 아쿠링, 야생 닭둘기
   2. 구현 된 퀘스트 : 마판 커뮤니티 카페에 올려진 퀘스트 기준 레벨8 까지의 퀘스트
   3. 구현 된 맵 : 리비 섬, 궁수의 길, 전사의 길, 마법의 언덕, 달맞이 언덕, 햄버거 언덕
   4. 구현 된 NPC : 리비 섬 NPC